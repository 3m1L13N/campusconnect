/* ==========================================================================
 * initialisation.c - Jeu de donnees de demonstration
 * --------------------------------------------------------------------------
 *  - 8 produits dans 4 categories, dont 2 en alerte (PRD-0002 et PRD-0007)
 *  - 5 clients avec adresses completes
 *  - 6 commandes couvrant les 4 statuts :
 *      1001 LIVREE   3 lignes  (palier 5 %)
 *      1002 EXPEDIEE 3 lignes  (> 600 EUR HT -> palier 15 %)
 *      1003 EN_COURS 2 lignes  (palier 5 %)
 *      1004 ANNULEE  1 ligne   (< 60 EUR -> frais de port)
 *      1005 LIVREE   4 lignes  (palier 10 %)
 *      1006 EN_COURS 1 ligne   (< 60 EUR -> frais de port)
 *  Les stocks indiques sont les stocks ACTUELS, apres ces commandes.
 * ========================================================================== */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "initialisation.h"
#include "produit.h"
#include "client.h"
#include "commande.h"

/* Une ligne de commande de demonstration : reference + quantite */
typedef struct
{
    const char *ref;
    int         quantite;
} LigneInit;

/* Cree une commande de demonstration et la rattache a son client */
static int creerCommandeInit(Boutique *b, int idClient, Date date, const char *statut,
                             const LigneInit *lignes, int nbLignes)
{
    Commande c;
    Client  *cl;
    int      idxClient = trouverClient(b, idClient);

    if (idxClient == -1) return 0;
    cl = &b->clients[idxClient];

    memset(&c, 0, sizeof c);
    c.numero       = b->numeroSuivant;
    c.idClient     = idClient;
    c.dateCommande = date;
    strcpy(c.statut, statut);
    c.adresseLivraison = cl->adresse;
    c.codePromo[0] = '\0';

    c.capaciteLignes = nbLignes;
    c.lignes = (LigneCommande *)malloc((size_t)c.capaciteLignes * sizeof(LigneCommande));
    if (c.lignes == NULL)
    {
        printf("  [!] Erreur memoire (lignes de la commande %d).\n", c.numero);
        return 0;
    }
    c.nbLignes = 0;

    for (int k = 0; k < nbLignes; k++)
    {
        int idxP = trouverProduit(b, lignes[k].ref);
        if (idxP == -1)
        {
            printf("  [!] Reference %s inconnue dans le jeu de test.\n", lignes[k].ref);
            free(c.lignes);
            return 0;
        }
        remplirLigne(&c.lignes[c.nbLignes++], &b->produits[idxP], lignes[k].quantite);
    }

    calculerCommande(&c);
    if (!ajouterCommandeAuClient(cl, &c))
    {
        free(c.lignes);
        return 0;
    }
    b->numeroSuivant++;
    cl->pointsFidelite += pointsCommande(&c); /* 0 pour une commande ANNULEE */
    return 1;
}

void initialiserBoutique(Boutique *b)
{
    strcpy(b->nom, "ShopFlow");
    b->produits         = NULL;
    b->nbProduits       = 0;
    b->capaciteProduits = 0;
    b->clients          = NULL;
    b->nbClients        = 0;
    b->capaciteClients  = 0;
    b->numeroSuivant    = 1001;
    b->idClientSuivant  = 1;
}

int initialiserDonneesTest(Boutique *b)
{
    /* 1. Catalogue : 10 emplacements pour 8 produits */
    Produit modeleProduits[] = {
        {"PRD-0001", "Clavier mecanique",  "Informatique",  79.90f,  42, 10, 1},
        {"PRD-0002", "Souris sans fil",    "Informatique",  24.50f,   8, 15, 1}, /* alerte */
        {"PRD-0003", "Ecran 27 pouces",    "Informatique", 199.00f,   6,  5, 1},
        {"PRD-0004", "Casque audio",       "Audio",         89.90f,  25, 10, 1},
        {"PRD-0005", "Enceinte Bluetooth", "Audio",         59.90f,  12,  8, 1},
        {"PRD-0006", "Cable HDMI 2 m",     "Accessoires",    9.90f, 120, 30, 1},
        {"PRD-0007", "Hub USB-C 7 ports",  "Accessoires",   49.90f,   4, 10, 1}, /* alerte */
        {"PRD-0008", "Disque SSD 1 To",    "Stockage",     109.00f,  18,  6, 1}
    };
    int nbModelesProduits = (int)(sizeof modeleProduits / sizeof modeleProduits[0]);

    /* 2. Clients : idClient et commandes sont remplis apres la copie */
    Client modeleClients[] = {
        {0, "Bernard", "Julie", "j.bernard@mail.fr", "0612345678",
         {"12 rue de la Paix", "Paris", "75002", "France"}, 0, 0, 0, NULL, 1},
        {0, "Martin", "Lucas", "l.martin@mail.fr", "0623456789",
         {"5 avenue Jean Jaures", "Lyon", "69007", "France"}, 0, 0, 0, NULL, 1},
        {0, "Dubois", "Emma", "e.dubois@mail.fr", "0634567890",
         {"8 boulevard Victor Hugo", "Nice", "06000", "France"}, 0, 0, 0, NULL, 1},
        {0, "Petit", "Hugo", "h.petit@mail.fr", "0645678901",
         {"27 rue Sainte-Catherine", "Bordeaux", "33000", "France"}, 0, 0, 0, NULL, 1},
        {0, "Moreau", "Chloe", "c.moreau@mail.fr", "0656789012",
         {"3 place du Capitole", "Toulouse", "31000", "France"}, 0, 0, 0, NULL, 1}
    };
    int nbModelesClients = (int)(sizeof modeleClients / sizeof modeleClients[0]);

    /* 3. Lignes des 6 commandes */
    LigneInit cmd1[] = {{"PRD-0001", 2}, {"PRD-0002", 1}, {"PRD-0006", 3}};
    LigneInit cmd2[] = {{"PRD-0003", 2}, {"PRD-0008", 2}, {"PRD-0006", 1}};
    LigneInit cmd3[] = {{"PRD-0004", 1}, {"PRD-0005", 1}};
    LigneInit cmd4[] = {{"PRD-0007", 1}};
    LigneInit cmd5[] = {{"PRD-0001", 1}, {"PRD-0004", 2}, {"PRD-0008", 1}, {"PRD-0006", 2}};
    LigneInit cmd6[] = {{"PRD-0002", 2}};

    /* --- Produits --- */
    b->capaciteProduits = 10;
    b->produits = (Produit *)malloc((size_t)b->capaciteProduits * sizeof(Produit));
    if (b->produits == NULL)
    {
        b->capaciteProduits = 0;
        printf("  [!] Erreur memoire (catalogue).\n");
        return 0;
    }
    for (int i = 0; i < nbModelesProduits; i++)
        b->produits[b->nbProduits++] = modeleProduits[i];

    /* --- Clients --- */
    b->capaciteClients = 8;
    b->clients = (Client *)malloc((size_t)b->capaciteClients * sizeof(Client));
    if (b->clients == NULL)
    {
        b->capaciteClients = 0;
        printf("  [!] Erreur memoire (clients).\n");
        return 0;
    }
    for (int i = 0; i < nbModelesClients; i++)
    {
        b->clients[b->nbClients] = modeleClients[i];
        b->clients[b->nbClients].idClient = b->idClientSuivant++;
        b->nbClients++;
    }

    /* --- Commandes (numeros 1001 a 1006 attribues par le compteur) --- */
    if (!creerCommandeInit(b, 1, (Date){12, 3, 2026}, STATUT_LIVREE,   cmd1, 3)) return 0;
    if (!creerCommandeInit(b, 2, (Date){5, 4, 2026},  STATUT_EXPEDIEE, cmd2, 3)) return 0;
    if (!creerCommandeInit(b, 3, (Date){20, 5, 2026}, STATUT_EN_COURS, cmd3, 2)) return 0;
    if (!creerCommandeInit(b, 1, (Date){2, 6, 2026},  STATUT_ANNULEE,  cmd4, 1)) return 0;
    if (!creerCommandeInit(b, 4, (Date){15, 9, 2026}, STATUT_LIVREE,   cmd5, 4)) return 0;
    if (!creerCommandeInit(b, 5, (Date){10, 10, 2026}, STATUT_EN_COURS, cmd6, 1)) return 0;

    return 1;
}

void detruireBoutique(Boutique *b)
{
    for (int i = 0; i < b->nbClients; i++)
    {
        for (int j = 0; j < b->clients[i].nbCommandes; j++)
            free(b->clients[i].commandes[j].lignes);   /* niveau 4 */
        free(b->clients[i].commandes);                 /* niveau 3 */
    }
    free(b->clients);                                  /* niveau 2 */
    free(b->produits);                                 /* niveau 1 */

    b->clients  = NULL;
    b->produits = NULL;
    b->nbClients = b->nbProduits = 0;
    b->capaciteClients = b->capaciteProduits = 0;
}
