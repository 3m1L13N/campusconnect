/* ==========================================================================
 * utils.c - Saisie securisee, validation des donnees, affichage formate
 * ========================================================================== */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "utils.h"

/* Passe a 1 quand stdin est ferme (Ctrl+D / fin de fichier) */
static int g_finSaisie = 0;

int finDeSaisie(void)
{
    return g_finSaisie;
}

/* Supprime les espaces au debut et a la fin d'une chaine */
static void supprimerEspaces(char *s)
{
    size_t debut = 0, len = strlen(s);

    while (len > 0 && isspace((unsigned char)s[len - 1]))
        s[--len] = '\0';
    while (s[debut] != '\0' && isspace((unsigned char)s[debut]))
        debut++;
    if (debut > 0)
        memmove(s, s + debut, len - debut + 1);
}

/* Lit une ligne complete avec fgets.
 * - jamais de debordement : au plus taille-1 caracteres sont gardes ;
 * - si la ligne est trop longue, le reste est vide du buffer clavier.
 * Retourne 1 si une ligne a ete lue, 0 si l'entree est fermee. */
static int lireLigne(char *dest, int taille)
{
    size_t len;

    if (g_finSaisie || fgets(dest, taille, stdin) == NULL)
    {
        g_finSaisie = 1;
        dest[0] = '\0';
        return 0;
    }
    len = strlen(dest);
    if (len > 0 && dest[len - 1] == '\n')
    {
        dest[len - 1] = '\0';
    }
    else
    {
        int c;
        while ((c = getchar()) != '\n' && c != EOF)
        {
            /* on jette les caracteres en trop */
        }
    }
    supprimerEspaces(dest);
    return 1;
}

void lireChaine(const char *message, char *dest, int taille)
{
    printf("%s", message);
    fflush(stdout);
    lireLigne(dest, taille);
}

void lireChaineNonVide(const char *message, char *dest, int taille)
{
    do
    {
        lireChaine(message, dest, taille);
        if (dest[0] == '\0' && !g_finSaisie)
            printf("  [!] Ce champ est obligatoire.\n");
    } while (dest[0] == '\0' && !g_finSaisie);
}

int lireEntier(const char *message, int min, int max)
{
    char  buffer[64];
    char *fin;
    long  valeur;

    while (1)
    {
        printf("%s", message);
        fflush(stdout);
        if (!lireLigne(buffer, (int)sizeof buffer))
            return (min <= 0 && max >= 0) ? 0 : min; /* entree fermee */

        valeur = strtol(buffer, &fin, 10);
        if (fin != buffer && *fin == '\0' && valeur >= min && valeur <= max)
            return (int)valeur;

        printf("  [!] Saisie invalide : entier entre %d et %d attendu.\n", min, max);
    }
}

float lireReel(const char *message, float min, float max)
{
    char  buffer[64];
    char *fin;
    float valeur;
    int   i;

    while (1)
    {
        printf("%s", message);
        fflush(stdout);
        if (!lireLigne(buffer, (int)sizeof buffer))
            return min; /* entree fermee */

        for (i = 0; buffer[i] != '\0'; i++) /* accepte 79,90 comme 79.90 */
            if (buffer[i] == ',')
                buffer[i] = '.';

        valeur = strtof(buffer, &fin);
        if (fin != buffer && *fin == '\0' && valeur >= min && valeur <= max)
            return valeur;

        printf("  [!] Saisie invalide : nombre entre %.2f et %.2f attendu.\n", min, max);
    }
}

/* ------------------------------------------------------------------------ */
/* Dates                                                                    */
/* ------------------------------------------------------------------------ */
int estBissextile(int annee)
{
    return (annee % 4 == 0 && annee % 100 != 0) || (annee % 400 == 0);
}

int dateValide(Date d)
{
    int joursParMois[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if (d.annee < 2000 || d.annee > 2100) return 0;
    if (d.mois < 1 || d.mois > 12)        return 0;
    if (estBissextile(d.annee))
        joursParMois[1] = 29;
    return d.jour >= 1 && d.jour <= joursParMois[d.mois - 1];
}

void saisirDate(const char *message, Date *d)
{
    printf("%s\n", message);
    do
    {
        d->jour  = lireEntier("    Jour  (1-31)      : ", 1, 31);
        d->mois  = lireEntier("    Mois  (1-12)      : ", 1, 12);
        d->annee = lireEntier("    Annee (2000-2100) : ", 2000, 2100);
        if (!dateValide(*d) && !g_finSaisie)
            printf("  [!] Date impossible (ex. 30/02 ou 29/02 hors annee bissextile).\n");
    } while (!dateValide(*d) && !g_finSaisie);
}

void afficherDate(Date d)
{
    printf("%02d/%02d/%04d", d.jour, d.mois, d.annee);
}

/* ------------------------------------------------------------------------ */
/* Validations                                                              */
/* ------------------------------------------------------------------------ */

/* Vrai si s contient exactement 'longueur' chiffres et rien d'autre */
static int estNumerique(const char *s, size_t longueur)
{
    size_t i;

    if (strlen(s) != longueur) return 0;
    for (i = 0; i < longueur; i++)
        if (!isdigit((unsigned char)s[i]))
            return 0;
    return 1;
}

/* Un seul '@', pas en premiere position, et un '.' dans la partie domaine */
int emailValide(const char *email)
{
    const char *arobase = strchr(email, '@');
    const char *point;

    if (arobase == NULL || arobase == email)  return 0;
    if (strchr(arobase + 1, '@') != NULL)      return 0;
    if (strchr(email, ' ') != NULL)            return 0;
    point = strchr(arobase + 1, '.');
    return point != NULL && point != arobase + 1 && point[1] != '\0';
}

int telephoneValide(const char *tel)
{
    return estNumerique(tel, 10);
}

int codePostalValide(const char *cp)
{
    return estNumerique(cp, 5);
}

/* ------------------------------------------------------------------------ */
/* Outils sur les chaines                                                   */
/* ------------------------------------------------------------------------ */
void enMajuscules(char *s)
{
    for (; *s != '\0'; s++)
        *s = (char)toupper((unsigned char)*s);
}

/* Recherche de motCle dans texte, sans tenir compte des majuscules */
int contientMotCle(const char *texte, const char *motCle)
{
    size_t i, j;
    size_t lt = strlen(texte), lm = strlen(motCle);

    if (lm == 0) return 1;
    for (i = 0; i + lm <= lt; i++)
    {
        for (j = 0; j < lm; j++)
            if (tolower((unsigned char)texte[i + j]) != tolower((unsigned char)motCle[j]))
                break;
        if (j == lm)
            return 1;
    }
    return 0;
}

int egalSansCasse(const char *a, const char *b)
{
    while (*a != '\0' && *b != '\0')
    {
        if (tolower((unsigned char)*a) != tolower((unsigned char)*b))
            return 0;
        a++;
        b++;
    }
    return *a == *b;
}

/* ------------------------------------------------------------------------ */
/* Divers                                                                   */
/* ------------------------------------------------------------------------ */
float arrondi2(float x)
{
    double v = (double)x * 100.0;
    long   r = (long)(v >= 0 ? v + 0.5 : v - 0.5);
    return (float)(r / 100.0);
}

void afficherSeparateur(void)
{
    printf("  ----------------------------------------------------------------------------------\n");
}
