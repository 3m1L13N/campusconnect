/* ==========================================================================
 * client.h - Module Clients
 * CRUD des clients, adresses de livraison, points de fidelite
 * ========================================================================== */
#ifndef CLIENT_H
#define CLIENT_H

#include "types.h"

/* Retourne l'indice du client dans b->clients (actif ou non), ou -1 */
int   trouverClient(const Boutique *b, int idClient);

/* Chiffre d'affaires d'un client, hors commandes ANNULEE.
 * enTTC = 0 -> montant HT, enTTC = 1 -> montant TTC */
float chiffreAffairesClient(const Client *c, int enTTC);

/* Nombre de commandes non annulees */
int   nbCommandesValides(const Client *c);

void saisirAdresse(Adresse *a);
void ajouterClient(Boutique *b);
void modifierClient(Boutique *b);
void supprimerClient(Boutique *b);
void afficherListeClients(const Boutique *b);
void afficherClient(const Boutique *b);

#endif /* CLIENT_H */
