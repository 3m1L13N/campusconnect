/* ==========================================================================
 * commande.c - Module Commandes
 * ========================================================================== */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "commande.h"
#include "produit.h"
#include "client.h"
#include "utils.h"

/* ------------------------------------------------------------------------ */
/* Bonus #2 : table des codes promotionnels                                 */
/* Applique APRES la remise par palier, sur le montant HT.                  */
/* ------------------------------------------------------------------------ */
typedef struct
{
    const char *code;
    int         estPourcentage; /* 1 = pourcentage, 0 = montant fixe en EUR */
    float       valeur;
} CodePromo;

static const CodePromo CODES_PROMO[] = {
    {"BIENVENUE",   1,  5.0f},  /* -5 % supplementaires      */
    {"ETUDIANT10",  1, 10.0f},  /* -10 % supplementaires     */
    {"FIXE15",      0, 15.0f}   /* -15 EUR sur le montant HT */
};
static const int NB_CODES_PROMO = (int)(sizeof CODES_PROMO / sizeof CODES_PROMO[0]);

static const CodePromo *chercherCodePromo(const char *code)
{
    for (int i = 0; i < NB_CODES_PROMO; i++)
        if (strcmp(CODES_PROMO[i].code, code) == 0)
            return &CODES_PROMO[i];
    return NULL;
}

/* ------------------------------------------------------------------------ */
/* Fonctions internes                                                       */
/* ------------------------------------------------------------------------ */

/* Palier de remise determine sur le montant HT BRUT */
static float tauxRemisePalier(float montantBrutHT)
{
    if (montantBrutHT >= 600.0f) return 15.0f;
    if (montantBrutHT >= 300.0f) return 10.0f;
    if (montantBrutHT >= 100.0f) return 5.0f;
    return 0.0f;
}

static int agrandirLignes(Commande *c)
{
    int nouvelleCapacite = (c->capaciteLignes == 0) ? CAPACITE_INIT_LIGNES
                                                    : c->capaciteLignes * 2;
    LigneCommande *tmp = (LigneCommande *)realloc(c->lignes,
                                                  (size_t)nouvelleCapacite * sizeof(LigneCommande));
    if (tmp == NULL)
    {
        printf("  [!] Erreur : memoire insuffisante, ligne non ajoutee.\n");
        return 0;
    }
    c->lignes = tmp;
    c->capaciteLignes = nouvelleCapacite;
    return 1;
}

static int agrandirCommandes(Client *cl)
{
    int nouvelleCapacite = (cl->capaciteCommandes == 0) ? CAPACITE_INIT_COMMANDES
                                                        : cl->capaciteCommandes * 2;
    Commande *tmp = (Commande *)realloc(cl->commandes,
                                        (size_t)nouvelleCapacite * sizeof(Commande));
    if (tmp == NULL)
    {
        printf("  [!] Erreur : memoire insuffisante, commande non enregistree.\n");
        return 0;
    }
    cl->commandes = tmp;
    cl->capaciteCommandes = nouvelleCapacite;
    return 1;
}

/* Indice de la ligne contenant cette reference, ou -1 */
static int trouverLigne(const Commande *c, const char *ref)
{
    for (int k = 0; k < c->nbLignes; k++)
        if (strcmp(c->lignes[k].refProduit, ref) == 0)
            return k;
    return -1;
}

/* Remet en stock la quantite d'une ligne (meme si le produit a ete desactive) */
static void reintegrerStock(Boutique *b, const LigneCommande *l)
{
    int idx = trouverProduit(b, l->refProduit);
    if (idx != -1)
        b->produits[idx].quantiteStock += l->quantite;
}

/* Met a jour les points du client apres un recalcul de commande */
static void majPoints(Client *cl, int anciensPoints, int nouveauxPoints)
{
    cl->pointsFidelite += nouveauxPoints - anciensPoints;
    if (cl->pointsFidelite < 0)
        cl->pointsFidelite = 0;
}

/* Demande un numero et retourne la commande (et son client), ou NULL.
 * Si enCoursObligatoire, refuse les commandes qui ne sont pas EN_COURS. */
static Commande *saisirCommande(Boutique *b, Client **proprietaire, int enCoursObligatoire)
{
    int       numero = lireEntier("  Numero de commande : ", 1, INT_MAX);
    Commande *c;

    if (finDeSaisie()) return NULL;
    c = trouverCommande(b, numero, proprietaire);
    if (c == NULL)
    {
        printf("  [!] Commande %d introuvable.\n", numero);
        return NULL;
    }
    if (enCoursObligatoire && strcmp(c->statut, STATUT_EN_COURS) != 0)
    {
        printf("  [!] Operation impossible : la commande %d est au statut %s (EN_COURS requis).\n",
               numero, c->statut);
        return NULL;
    }
    return c;
}

/* Saisie d'un code promo (vide = aucun code). Retourne 1 si un code est applique. */
static int saisirCodePromo(Commande *c)
{
    char code[TAILLE_CODE_PROMO];

    printf("  Codes disponibles : BIENVENUE (-5 %%), ETUDIANT10 (-10 %%), FIXE15 (-15 EUR HT)\n");
    while (!finDeSaisie())
    {
        lireChaine("  Code promo (vide = aucun) : ", code, (int)sizeof code);
        enMajuscules(code);
        if (code[0] == '\0')
        {
            c->codePromo[0] = '\0';
            return 0;
        }
        if (chercherCodePromo(code) != NULL)
        {
            strcpy(c->codePromo, code);
            printf("  [OK] Code %s applique.\n", code);
            return 1;
        }
        printf("  [!] Code promo inconnu.\n");
    }
    return 0;
}

/* ------------------------------------------------------------------------ */
/* Calculs                                                                  */
/* ------------------------------------------------------------------------ */

void remplirLigne(LigneCommande *l, const Produit *p, int quantite)
{
    strcpy(l->refProduit, p->reference);
    strcpy(l->designation, p->designation);
    l->quantite       = quantite;
    l->prixUnitaireHT = p->prixUnitaireHT;
    l->sousTotalHT    = arrondi2((float)quantite * p->prixUnitaireHT);
}

void calculerCommande(Commande *c)
{
    const CodePromo *promo;
    float htApresRemise;

    /* 1. Montant brut = somme des sous-totaux des lignes */
    c->montantBrutHT = 0.0f;
    for (int k = 0; k < c->nbLignes; k++)
    {
        c->lignes[k].sousTotalHT = arrondi2((float)c->lignes[k].quantite * c->lignes[k].prixUnitaireHT);
        c->montantBrutHT += c->lignes[k].sousTotalHT;
    }
    c->montantBrutHT = arrondi2(c->montantBrutHT);

    /* 2. Remise par palier, determinee sur le brut */
    c->tauxRemise    = tauxRemisePalier(c->montantBrutHT);
    c->montantRemise = arrondi2(c->montantBrutHT * c->tauxRemise / 100.0f);
    htApresRemise    = c->montantBrutHT - c->montantRemise;

    /* 3. Bonus : code promo applique apres la remise palier */
    c->montantPromo = 0.0f;
    promo = chercherCodePromo(c->codePromo);
    if (promo != NULL)
    {
        c->montantPromo = promo->estPourcentage ? arrondi2(htApresRemise * promo->valeur / 100.0f)
                                                : promo->valeur;
        if (c->montantPromo > htApresRemise) /* le HT ne descend jamais sous 0 */
            c->montantPromo = htApresRemise;
    }

    /* 4. HT, TVA (sur le HT apres remise), port (sur le brut), TTC */
    c->montantHT  = arrondi2(htApresRemise - c->montantPromo);
    c->montantTVA = arrondi2(c->montantHT * TAUX_TVA / 100.0f);
    c->fraisPort  = (c->montantBrutHT >= SEUIL_PORT_OFFERT) ? 0.0f : FRAIS_PORT;
    c->montantTTC = arrondi2(c->montantHT + c->montantTVA + c->fraisPort);
}

int pointsCommande(const Commande *c)
{
    if (strcmp(c->statut, STATUT_ANNULEE) == 0)
        return 0;
    /* 1 point par tranche COMPLETE de 10 EUR TTC (port inclus) ;
     * +0.001 evite qu'un 99.99999 (erreur d'arrondi float) donne 9 au lieu de 10 */
    return (int)((c->montantTTC + 0.001f) / EUROS_PAR_POINT);
}

int ajouterCommandeAuClient(Client *cl, const Commande *c)
{
    if (cl->nbCommandes == cl->capaciteCommandes && !agrandirCommandes(cl))
        return 0;
    cl->commandes[cl->nbCommandes++] = *c;
    return 1;
}

Commande *trouverCommande(Boutique *b, int numero, Client **proprietaire)
{
    for (int i = 0; i < b->nbClients; i++)
        for (int j = 0; j < b->clients[i].nbCommandes; j++)
            if (b->clients[i].commandes[j].numero == numero)
            {
                if (proprietaire != NULL)
                    *proprietaire = &b->clients[i];
                return &b->clients[i].commandes[j];
            }
    return NULL;
}

/* ------------------------------------------------------------------------ */
/* Affichage                                                                */
/* ------------------------------------------------------------------------ */

void afficherDetailCommande(const Commande *c)
{
    afficherSeparateur();
    printf("  Commande n.%d - client %d - date ", c->numero, c->idClient);
    afficherDate(c->dateCommande);
    printf(" - statut %s\n", c->statut);
    printf("  Livraison : %s, %s %s, %s\n", c->adresseLivraison.rue,
           c->adresseLivraison.codePostal, c->adresseLivraison.ville, c->adresseLivraison.pays);
    afficherSeparateur();
    printf("  %-3s %-10s %-26s %5s %10s %12s\n", "#", "Reference", "Designation", "Qte", "PU HT", "Sous-total");
    for (int k = 0; k < c->nbLignes; k++)
    {
        const LigneCommande *l = &c->lignes[k];
        printf("  %-3d %-10s %-26.26s %5d %10.2f %12.2f\n",
               k + 1, l->refProduit, l->designation, l->quantite, l->prixUnitaireHT, l->sousTotalHT);
    }
    afficherSeparateur();
    printf("  %-40s %12.2f EUR\n", "Montant brut HT", c->montantBrutHT);
    printf("  Remise palier (%2.0f %%)                     %12.2f EUR\n", c->tauxRemise, -c->montantRemise);
    if (c->codePromo[0] != '\0')
        printf("  Code promo %-28s %12.2f EUR\n", c->codePromo, -c->montantPromo);
    printf("  %-40s %12.2f EUR\n", "Montant HT", c->montantHT);
    printf("  %-40s %12.2f EUR\n", "TVA 20 %", c->montantTVA);
    printf("  %-40s %12.2f EUR%s\n", "Frais de port", c->fraisPort,
           (c->fraisPort == 0.0f) ? " (offerts)" : "");
    printf("  %-40s %12.2f EUR\n", "TOTAL TTC", c->montantTTC);
    printf("  %-40s %12d\n", "Points de fidelite", pointsCommande(c));
    afficherSeparateur();
}

void afficherUneCommande(Boutique *b)
{
    Client   *cl = NULL;
    Commande *c;

    printf("\n--- Affichage d'une commande ---\n");
    c = saisirCommande(b, &cl, 0);
    if (c == NULL) return;
    printf("  Client : %s %s\n", cl->prenom, cl->nom);
    afficherDetailCommande(c);
}

/* ------------------------------------------------------------------------ */
/* Creation et cycle de vie                                                 */
/* ------------------------------------------------------------------------ */

void creerCommande(Boutique *b)
{
    Commande c;
    Client  *cl;
    char     ref[TAILLE_REF];
    int      idClient, idxClient;

    printf("\n--- Creation d'une commande ---\n");
    idClient  = lireEntier("  Identifiant du client : ", 1, INT_MAX);
    if (finDeSaisie()) return;
    idxClient = trouverClient(b, idClient);
    if (idxClient == -1 || !b->clients[idxClient].actif)
    {
        printf("  [!] Aucun client actif avec l'identifiant %d.\n", idClient);
        return;
    }

    memset(&c, 0, sizeof c);
    c.idClient = idClient;
    saisirDate("  Date de la commande :", &c.dateCommande);
    if (finDeSaisie()) return;

    c.capaciteLignes = CAPACITE_INIT_LIGNES;
    c.lignes = (LigneCommande *)malloc((size_t)c.capaciteLignes * sizeof(LigneCommande));
    if (c.lignes == NULL)
    {
        printf("  [!] Erreur : memoire insuffisante.\n");
        return;
    }
    c.nbLignes = 0;

    /* Saisie de N lignes : le nombre n'est pas connu a l'avance */
    while (!finDeSaisie())
    {
        int      idxP, idxL, dejaDansCommande, disponible, qte;
        Produit *p;

        printf("\n  Ligne %d\n", c.nbLignes + 1);
        lireChaine("  Reference produit (vide pour terminer) : ", ref, (int)sizeof ref);
        if (ref[0] == '\0') break;
        enMajuscules(ref);

        idxP = trouverProduit(b, ref);
        if (idxP == -1 || !b->produits[idxP].actif)
        {
            printf("  [!] Produit %s introuvable ou supprime.\n", ref);
            continue;
        }
        p = &b->produits[idxP];

        /* Une seule ligne par reference : controle sur la quantite CUMULEE */
        idxL = trouverLigne(&c, ref);
        dejaDansCommande = (idxL == -1) ? 0 : c.lignes[idxL].quantite;
        disponible = p->quantiteStock - dejaDansCommande;
        if (disponible <= 0)
        {
            printf("  [!] Rupture de stock pour %s.\n", ref);
            continue;
        }
        printf("  %s - %.2f EUR HT - disponible : %d\n", p->designation, p->prixUnitaireHT, disponible);
        qte = lireEntier("  Quantite : ", 1, disponible);
        if (finDeSaisie()) break;

        if (idxL != -1)
        {
            c.lignes[idxL].quantite += qte;
            printf("  [OK] Quantite cumulee sur la ligne existante : %d.\n", c.lignes[idxL].quantite);
        }
        else
        {
            if (c.nbLignes == c.capaciteLignes && !agrandirLignes(&c))
                continue;
            remplirLigne(&c.lignes[c.nbLignes++], p, qte);
        }
    }

    if (c.nbLignes == 0 || finDeSaisie())
    {
        printf("  Commande abandonnee.\n");
        free(c.lignes);
        return;
    }

    saisirCodePromo(&c);

    /* Validation : numero attribue par la boutique, adresse recopiee */
    cl = &b->clients[idxClient];
    c.numero = b->numeroSuivant;
    strcpy(c.statut, STATUT_EN_COURS);
    c.adresseLivraison = cl->adresse;
    calculerCommande(&c);

    if (!ajouterCommandeAuClient(cl, &c))
    {
        free(c.lignes);
        return;
    }
    b->numeroSuivant++;

    /* Decrement du stock et credit des points */
    for (int k = 0; k < c.nbLignes; k++)
        b->produits[trouverProduit(b, c.lignes[k].refProduit)].quantiteStock -= c.lignes[k].quantite;
    cl->pointsFidelite += pointsCommande(&c);

    printf("\n  [OK] Commande %d creee.\n", c.numero);
    afficherDetailCommande(&c);
}

void ajouterLigneCommande(Boutique *b)
{
    Client   *cl = NULL;
    Commande *c;
    Produit  *p;
    char      ref[TAILLE_REF];
    int       idxP, idxL, qte, anciensPoints;

    printf("\n--- Ajout d'une ligne a une commande ---\n");
    c = saisirCommande(b, &cl, 1);
    if (c == NULL) return;

    lireChaineNonVide("  Reference produit : ", ref, (int)sizeof ref);
    if (finDeSaisie()) return;
    enMajuscules(ref);
    idxP = trouverProduit(b, ref);
    if (idxP == -1 || !b->produits[idxP].actif)
    {
        printf("  [!] Produit %s introuvable ou supprime.\n", ref);
        return;
    }
    p = &b->produits[idxP];
    /* Le stock a deja ete decremente pour les lignes existantes :
     * le disponible est donc directement quantiteStock. */
    if (p->quantiteStock <= 0)
    {
        printf("  [!] Rupture de stock pour %s.\n", ref);
        return;
    }
    printf("  %s - %.2f EUR HT - disponible : %d\n", p->designation, p->prixUnitaireHT, p->quantiteStock);
    qte = lireEntier("  Quantite : ", 1, p->quantiteStock);
    if (finDeSaisie()) return;

    anciensPoints = pointsCommande(c);
    idxL = trouverLigne(c, ref);
    if (idxL != -1)
    {
        c->lignes[idxL].quantite += qte; /* pas de doublon de reference */
    }
    else
    {
        if (c->nbLignes == c->capaciteLignes && !agrandirLignes(c))
            return;
        remplirLigne(&c->lignes[c->nbLignes++], p, qte);
    }
    p->quantiteStock -= qte;
    calculerCommande(c);
    majPoints(cl, anciensPoints, pointsCommande(c));

    printf("  [OK] Ligne ajoutee.\n");
    afficherDetailCommande(c);
}

void supprimerLigneCommande(Boutique *b)
{
    Client   *cl = NULL;
    Commande *c;
    int       num, anciensPoints;

    printf("\n--- Suppression d'une ligne de commande ---\n");
    c = saisirCommande(b, &cl, 1);
    if (c == NULL) return;

    if (c->nbLignes <= 1)
    {
        printf("  [!] Une commande doit garder au moins une ligne : utilisez plutot l'annulation.\n");
        return;
    }
    afficherDetailCommande(c);
    num = lireEntier("  Numero de la ligne a supprimer : ", 1, c->nbLignes);
    if (finDeSaisie()) return;

    anciensPoints = pointsCommande(c);
    reintegrerStock(b, &c->lignes[num - 1]);
    for (int k = num - 1; k < c->nbLignes - 1; k++) /* decalage vers la gauche */
        c->lignes[k] = c->lignes[k + 1];
    c->nbLignes--;
    calculerCommande(c);
    majPoints(cl, anciensPoints, pointsCommande(c));

    printf("  [OK] Ligne supprimee, stock reintegre.\n");
    afficherDetailCommande(c);
}

void changerStatutCommande(Boutique *b)
{
    Client     *cl = NULL;
    Commande   *c;
    const char *suivant;

    printf("\n--- Changement de statut ---\n");
    c = saisirCommande(b, &cl, 0);
    if (c == NULL) return;

    /* Progression autorisee : EN_COURS -> EXPEDIEE -> LIVREE, sans retour */
    if (strcmp(c->statut, STATUT_EN_COURS) == 0)
        suivant = STATUT_EXPEDIEE;
    else if (strcmp(c->statut, STATUT_EXPEDIEE) == 0)
        suivant = STATUT_LIVREE;
    else
    {
        printf("  [!] La commande %d est %s : aucun changement de statut possible.\n",
               c->numero, c->statut);
        return;
    }

    printf("  Passer la commande %d de %s a %s ?\n", c->numero, c->statut, suivant);
    if (lireEntier("  (1 = oui, 0 = non) : ", 0, 1) == 1)
    {
        strcpy(c->statut, suivant);
        printf("  [OK] Commande %d : statut %s.\n", c->numero, c->statut);
    }
}

void annulerCommande(Boutique *b)
{
    Client   *cl = NULL;
    Commande *c;

    printf("\n--- Annulation d'une commande ---\n");
    c = saisirCommande(b, &cl, 1); /* annulation possible seulement EN_COURS */
    if (c == NULL) return;

    printf("  Confirmer l'annulation de la commande %d (%.2f EUR TTC) ?\n", c->numero, c->montantTTC);
    if (lireEntier("  (1 = oui, 0 = non) : ", 0, 1) != 1)
        return;

    majPoints(cl, pointsCommande(c), 0); /* retrait des points */
    for (int k = 0; k < c->nbLignes; k++)
        reintegrerStock(b, &c->lignes[k]);
    strcpy(c->statut, STATUT_ANNULEE);
    printf("  [OK] Commande %d annulee : stock reintegre et points retires.\n", c->numero);
}

void appliquerCodePromo(Boutique *b)
{
    Client   *cl = NULL;
    Commande *c;
    int       anciensPoints;

    printf("\n--- Code promotionnel ---\n");
    c = saisirCommande(b, &cl, 1);
    if (c == NULL) return;

    anciensPoints = pointsCommande(c);
    saisirCodePromo(c);
    calculerCommande(c);
    majPoints(cl, anciensPoints, pointsCommande(c));
    afficherDetailCommande(c);
}
