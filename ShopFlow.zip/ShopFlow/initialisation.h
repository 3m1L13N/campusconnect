/* ==========================================================================
 * initialisation.h - Jeu de donnees de demonstration et liberation memoire
 * ========================================================================== */
#ifndef INITIALISATION_H
#define INITIALISATION_H

#include "types.h"

/* Met la boutique dans un etat vide et coherent (pointeurs a NULL) */
void initialiserBoutique(Boutique *b);

/* Charge 8 produits, 5 clients et 6 commandes. Retourne 1 si OK, 0 sinon. */
int  initialiserDonneesTest(Boutique *b);

/* Liberation en cascade : lignes -> commandes -> clients -> produits */
void detruireBoutique(Boutique *b);

#endif /* INITIALISATION_H */
