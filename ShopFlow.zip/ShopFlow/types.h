/* ==========================================================================
 * types.h - Structures partagees et constantes du projet ShopFlow
 * --------------------------------------------------------------------------
 * Inclus par TOUS les modules : evite les inclusions circulaires entre
 * client.h et commande.h.
 * ========================================================================== */
#ifndef TYPES_H
#define TYPES_H

/* --- Tailles des chaines (caractere de fin '\0' compris) ----------------- */
#define TAILLE_REF          12
#define TAILLE_DESIGNATION  60
#define TAILLE_CATEGORIE    30
#define TAILLE_RUE          80
#define TAILLE_VILLE        50
#define TAILLE_CP            6
#define TAILLE_PAYS         50
#define TAILLE_NOM          50
#define TAILLE_EMAIL        80
#define TAILLE_TEL          15
#define TAILLE_STATUT       20
#define TAILLE_CODE_PROMO   16

/* --- Regles de facturation ----------------------------------------------- */
#define TAUX_TVA            20.0f   /* % applique sur le HT apres remise     */
#define FRAIS_PORT           5.90f  /* frais de port standard                */
#define SEUIL_PORT_OFFERT   60.0f   /* port offert des 60 EUR HT brut        */
#define EUROS_PAR_POINT     10.0f   /* 1 point fidelite par tranche de 10 EUR */

/* --- Statuts possibles d'une commande ------------------------------------ */
#define STATUT_EN_COURS "EN_COURS"
#define STATUT_EXPEDIEE "EXPEDIEE"
#define STATUT_LIVREE   "LIVREE"
#define STATUT_ANNULEE  "ANNULEE"

/* --- Capacites initiales des tableaux dynamiques ------------------------- */
#define CAPACITE_INIT_LIGNES     2
#define CAPACITE_INIT_COMMANDES  2
#define CAPACITE_INIT_PRODUITS   4
#define CAPACITE_INIT_CLIENTS    4

/* 3.1.1 Date */
typedef struct
{
    int jour;
    int mois;
    int annee;
} Date;

/* 3.1.2 Adresse */
typedef struct
{
    char rue[TAILLE_RUE];
    char ville[TAILLE_VILLE];
    char codePostal[TAILLE_CP];
    char pays[TAILLE_PAYS];
} Adresse;

/* 3.1.3 Produit */
typedef struct
{
    char  reference[TAILLE_REF];
    char  designation[TAILLE_DESIGNATION];
    char  categorie[TAILLE_CATEGORIE];
    float prixUnitaireHT;
    int   quantiteStock;
    int   seuilAlerte;
    int   actif;               /* 1 = actif, 0 = supprime (logique) */
} Produit;

/* 3.1.4 LigneCommande */
typedef struct
{
    char  refProduit[TAILLE_REF];
    char  designation[TAILLE_DESIGNATION]; /* figee au moment de la vente */
    int   quantite;
    float prixUnitaireHT;                  /* fige au moment de la vente  */
    float sousTotalHT;                     /* quantite x prixUnitaireHT   */
} LigneCommande;

/* 3.1.5 Commande */
typedef struct
{
    int            numero;
    int            idClient;
    Date           dateCommande;
    char           statut[TAILLE_STATUT];
    int            nbLignes;
    int            capaciteLignes;
    LigneCommande *lignes;          /* tableau dynamique */
    float          montantBrutHT;
    float          tauxRemise;      /* 0, 5, 10 ou 15 */
    float          montantRemise;
    float          montantHT;
    float          montantTVA;
    float          montantTTC;
    float          fraisPort;
    Adresse        adresseLivraison;
    /* Bonus creativite #2 : code promotionnel */
    char           codePromo[TAILLE_CODE_PROMO];
    float          montantPromo;
} Commande;

/* 3.1.6 Client */
typedef struct
{
    int       idClient;
    char      nom[TAILLE_NOM];
    char      prenom[TAILLE_NOM];
    char      email[TAILLE_EMAIL];
    char      telephone[TAILLE_TEL];
    Adresse   adresse;
    int       pointsFidelite;
    int       nbCommandes;
    int       capaciteCommandes;
    Commande *commandes;            /* tableau dynamique */
    int       actif;
} Client;

/* 3.1.7 Boutique (structure racine) */
typedef struct
{
    char     nom[TAILLE_NOM];
    Produit *produits;              /* tableau dynamique */
    int      nbProduits;
    int      capaciteProduits;
    Client  *clients;               /* tableau dynamique */
    int      nbClients;
    int      capaciteClients;
    int      numeroSuivant;         /* prochain numero de commande */
    int      idClientSuivant;       /* prochain identifiant client */
} Boutique;

#endif /* TYPES_H */
