/* ==========================================================================
 * statistique.c - Module Statistiques
 * ========================================================================== */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "statistique.h"
#include "client.h"
#include "utils.h"

#define TOP_PRODUITS 5

/* Element du palmares produits : indice dans le catalogue + quantite vendue */
typedef struct
{
    int indice;
    int quantite;
} VenteProduit;

/* Element du palmares clients : indice dans le repertoire + CA HT */
typedef struct
{
    int   indice;
    float ca;
} CAClient;

/* ------------------------------------------------------------------------ */
/* Tris par selection (ordre decroissant)                                   */
/* ------------------------------------------------------------------------ */
static void trierVentes(VenteProduit *t, int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        int iMax = i;
        for (int j = i + 1; j < n; j++)
            if (t[j].quantite > t[iMax].quantite)
                iMax = j;
        if (iMax != i)
        {
            VenteProduit tmp = t[i];
            t[i] = t[iMax];
            t[iMax] = tmp;
        }
    }
}

static void trierClients(CAClient *t, int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        int iMax = i;
        for (int j = i + 1; j < n; j++)
            if (t[j].ca > t[iMax].ca)
                iMax = j;
        if (iMax != i)
        {
            CAClient tmp = t[i];
            t[i] = t[iMax];
            t[iMax] = tmp;
        }
    }
}

/* Somme HT et TTC des commandes non annulees sur une periode.
 * annee = 0 -> toutes les annees ; mois = 0 -> tous les mois. */
static int calculerCA(const Boutique *b, int annee, int mois, float *totalHT, float *totalTTC)
{
    int nb = 0;

    *totalHT = 0.0f;
    *totalTTC = 0.0f;
    for (int i = 0; i < b->nbClients; i++)
        for (int j = 0; j < b->clients[i].nbCommandes; j++)
        {
            const Commande *c = &b->clients[i].commandes[j];
            if (strcmp(c->statut, STATUT_ANNULEE) == 0)              continue;
            if (annee != 0 && c->dateCommande.annee != annee)        continue;
            if (mois != 0 && c->dateCommande.mois != mois)           continue;
            *totalHT  += c->montantHT;
            *totalTTC += c->montantTTC;
            nb++;
        }
    return nb;
}

/* ------------------------------------------------------------------------ */
/* Fonctions publiques                                                      */
/* ------------------------------------------------------------------------ */

void afficherChiffreAffaires(const Boutique *b)
{
    float ht, ttc;
    int   nb = calculerCA(b, 0, 0, &ht, &ttc);

    printf("\n--- Chiffre d'affaires global de %s ---\n", b->nom);
    printf("  Commandes prises en compte (hors annulees) : %d\n", nb);
    printf("  Total HT  : %12.2f EUR\n", ht);
    printf("  Total TTC : %12.2f EUR\n", ttc);
}

void afficherCAParPeriode(const Boutique *b)
{
    float ht, ttc;
    int   annee, mois, nb;

    printf("\n--- Chiffre d'affaires par periode ---\n");
    annee = lireEntier("  Annee (2000-2100) : ", 2000, 2100);
    mois  = lireEntier("  Mois (1-12, 0 = annee entiere) : ", 0, 12);
    if (finDeSaisie()) return;

    if (mois == 0)
    {
        /* Detail mois par mois puis total annuel */
        printf("  %-8s %10s %14s %14s\n", "Mois", "Commandes", "CA HT", "CA TTC");
        for (int m = 1; m <= 12; m++)
        {
            nb = calculerCA(b, annee, m, &ht, &ttc);
            if (nb > 0)
                printf("  %02d/%04d  %10d %14.2f %14.2f\n", m, annee, nb, ht, ttc);
        }
        nb = calculerCA(b, annee, 0, &ht, &ttc);
        printf("  Total %04d : %d commande(s) - %.2f EUR HT - %.2f EUR TTC\n", annee, nb, ht, ttc);
    }
    else
    {
        nb = calculerCA(b, annee, mois, &ht, &ttc);
        printf("  %02d/%04d : %d commande(s) - %.2f EUR HT - %.2f EUR TTC\n", mois, annee, nb, ht, ttc);
    }
}

void afficherPalmaresProduits(const Boutique *b)
{
    VenteProduit *ventes;
    int           affiches = 0;

    printf("\n--- Palmares produits (top %d par quantite vendue) ---\n", TOP_PRODUITS);
    if (b->nbProduits == 0)
    {
        printf("  Catalogue vide.\n");
        return;
    }
    ventes = (VenteProduit *)malloc((size_t)b->nbProduits * sizeof(VenteProduit));
    if (ventes == NULL)
    {
        printf("  [!] Erreur : memoire insuffisante.\n");
        return;
    }

    /* Cumul des quantites sur les lignes des commandes non annulees */
    for (int p = 0; p < b->nbProduits; p++)
    {
        ventes[p].indice = p;
        ventes[p].quantite = 0;
    }
    for (int i = 0; i < b->nbClients; i++)
        for (int j = 0; j < b->clients[i].nbCommandes; j++)
        {
            const Commande *c = &b->clients[i].commandes[j];
            if (strcmp(c->statut, STATUT_ANNULEE) == 0) continue;
            for (int k = 0; k < c->nbLignes; k++)
                for (int p = 0; p < b->nbProduits; p++)
                    if (strcmp(b->produits[p].reference, c->lignes[k].refProduit) == 0)
                    {
                        ventes[p].quantite += c->lignes[k].quantite;
                        break;
                    }
        }

    trierVentes(ventes, b->nbProduits);

    printf("  %-4s %-10s %-26s %10s\n", "Rang", "Reference", "Designation", "Qte vendue");
    for (int r = 0; r < b->nbProduits && affiches < TOP_PRODUITS; r++)
    {
        const Produit *pr = &b->produits[ventes[r].indice];
        if (ventes[r].quantite == 0) break;
        printf("  %-4d %-10s %-26.26s %10d\n", r + 1, pr->reference, pr->designation, ventes[r].quantite);
        affiches++;
    }
    if (affiches == 0)
        printf("  Aucune vente enregistree.\n");

    free(ventes);
}

void afficherPalmaresClients(const Boutique *b)
{
    CAClient *classement;

    printf("\n--- Palmares clients (par chiffre d'affaires HT) ---\n");
    if (b->nbClients == 0)
    {
        printf("  Aucun client.\n");
        return;
    }
    classement = (CAClient *)malloc((size_t)b->nbClients * sizeof(CAClient));
    if (classement == NULL)
    {
        printf("  [!] Erreur : memoire insuffisante.\n");
        return;
    }

    for (int i = 0; i < b->nbClients; i++)
    {
        classement[i].indice = i;
        classement[i].ca = chiffreAffairesClient(&b->clients[i], 0);
    }
    trierClients(classement, b->nbClients);

    printf("  %-4s %-4s %-26s %5s %12s %12s\n", "Rang", "Id", "Client", "Cmd", "CA HT", "CA TTC");
    for (int r = 0; r < b->nbClients; r++)
    {
        const Client *c = &b->clients[classement[r].indice];
        char nomComplet[2 * TAILLE_NOM + 1];

        snprintf(nomComplet, sizeof nomComplet, "%s %s", c->prenom, c->nom);
        printf("  %-4d %-4d %-26.26s %5d %12.2f %12.2f%s\n", r + 1, c->idClient, nomComplet,
               nbCommandesValides(c), classement[r].ca, chiffreAffairesClient(c, 1),
               c->actif ? "" : " (supprime)");
    }
    free(classement);
}
