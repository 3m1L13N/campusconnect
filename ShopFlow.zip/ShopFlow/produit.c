/* ==========================================================================
 * produit.c - Module Catalogue produits
 * ========================================================================== */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "produit.h"
#include "utils.h"

/* ------------------------------------------------------------------------ */
/* Fonctions internes                                                       */
/* ------------------------------------------------------------------------ */

/* Double la capacite du catalogue avec realloc. Retourne 1 si OK. */
static int agrandirCatalogue(Boutique *b)
{
    int nouvelleCapacite = (b->capaciteProduits == 0) ? CAPACITE_INIT_PRODUITS
                                                      : b->capaciteProduits * 2;
    Produit *tmp = (Produit *)realloc(b->produits, (size_t)nouvelleCapacite * sizeof(Produit));

    if (tmp == NULL)
    {
        printf("  [!] Erreur : memoire insuffisante, produit non ajoute.\n");
        return 0; /* l'ancien tableau reste valide */
    }
    b->produits = tmp;
    b->capaciteProduits = nouvelleCapacite;
    return 1;
}

static void afficherEnteteProduits(void)
{
    afficherSeparateur();
    printf("  %-10s %-24s %-14s %9s %6s %6s %12s\n",
           "Reference", "Designation", "Categorie", "Prix HT", "Stock", "Seuil", "Valeur stock");
    afficherSeparateur();
}

static void afficherLigneProduit(const Produit *p)
{
    printf("  %-10s %-24.24s %-14.14s %9.2f %6d %6d %12.2f %s\n",
           p->reference, p->designation, p->categorie, p->prixUnitaireHT,
           p->quantiteStock, p->seuilAlerte,
           p->prixUnitaireHT * (float)p->quantiteStock,
           (p->quantiteStock <= p->seuilAlerte) ? "(!) ALERTE" : "");
}

/* Demande une reference et retourne l'indice d'un produit ACTIF, ou -1 */
static int saisirProduitActif(const Boutique *b)
{
    char ref[TAILLE_REF];
    int  idx;

    lireChaineNonVide("  Reference du produit : ", ref, (int)sizeof ref);
    if (finDeSaisie()) return -1;
    enMajuscules(ref);
    idx = trouverProduit(b, ref);
    if (idx == -1 || !b->produits[idx].actif)
    {
        printf("  [!] Aucun produit actif avec la reference %s.\n", ref);
        return -1;
    }
    return idx;
}

/* ------------------------------------------------------------------------ */
/* Fonctions publiques                                                      */
/* ------------------------------------------------------------------------ */

int trouverProduit(const Boutique *b, const char *reference)
{
    for (int i = 0; i < b->nbProduits; i++)
        if (strcmp(b->produits[i].reference, reference) == 0)
            return i;
    return -1;
}

int produitUtiliseDansCommande(const Boutique *b, const char *reference)
{
    for (int i = 0; i < b->nbClients; i++)
    {
        const Client *cl = &b->clients[i];
        for (int j = 0; j < cl->nbCommandes; j++)
        {
            const Commande *c = &cl->commandes[j];
            if (strcmp(c->statut, STATUT_ANNULEE) == 0)
                continue;
            for (int k = 0; k < c->nbLignes; k++)
                if (strcmp(c->lignes[k].refProduit, reference) == 0)
                    return 1;
        }
    }
    return 0;
}

void ajouterProduit(Boutique *b)
{
    Produit p;

    printf("\n--- Ajout d'un produit ---\n");
    lireChaineNonVide("  Reference (ex. PRD-0009) : ", p.reference, (int)sizeof p.reference);
    if (finDeSaisie()) return;
    enMajuscules(p.reference);

    /* Unicite controlee sur TOUS les produits, y compris supprimes */
    if (trouverProduit(b, p.reference) != -1)
    {
        printf("  [!] La reference %s existe deja (eventuellement supprimee).\n", p.reference);
        return;
    }

    lireChaineNonVide("  Designation : ", p.designation, (int)sizeof p.designation);
    lireChaineNonVide("  Categorie   : ", p.categorie, (int)sizeof p.categorie);
    p.prixUnitaireHT = lireReel("  Prix unitaire HT : ", 0.01f, 1000000.0f);
    p.quantiteStock  = lireEntier("  Quantite en stock : ", 0, 1000000);
    p.seuilAlerte    = lireEntier("  Seuil d'alerte    : ", 0, 1000000);
    p.actif = 1;
    if (finDeSaisie()) return;

    if (b->nbProduits == b->capaciteProduits && !agrandirCatalogue(b))
        return;

    b->produits[b->nbProduits++] = p;
    printf("  [OK] Produit %s ajoute au catalogue.\n", p.reference);
}

void modifierProduit(Boutique *b)
{
    int      idx;
    Produit *p;

    printf("\n--- Modification d'un produit ---\n");
    idx = saisirProduitActif(b);
    if (idx == -1) return;
    p = &b->produits[idx];

    printf("  Actuel : %s - prix %.2f EUR HT - stock %d - seuil %d\n",
           p->designation, p->prixUnitaireHT, p->quantiteStock, p->seuilAlerte);
    p->prixUnitaireHT = lireReel("  Nouveau prix unitaire HT : ", 0.01f, 1000000.0f);
    p->quantiteStock  = lireEntier("  Nouveau stock            : ", 0, 1000000);
    p->seuilAlerte    = lireEntier("  Nouveau seuil d'alerte   : ", 0, 1000000);
    printf("  [OK] Produit %s mis a jour.\n", p->reference);
}

void supprimerProduit(Boutique *b)
{
    int idx;

    printf("\n--- Suppression d'un produit ---\n");
    idx = saisirProduitActif(b);
    if (idx == -1) return;

    if (produitUtiliseDansCommande(b, b->produits[idx].reference))
    {
        printf("  [!] Suppression refusee : %s figure dans une commande non annulee.\n",
               b->produits[idx].reference);
        return;
    }
    b->produits[idx].actif = 0; /* suppression logique */
    printf("  [OK] Produit %s supprime (desactive).\n", b->produits[idx].reference);
}

void afficherCatalogue(const Boutique *b)
{
    float valorisation = 0.0f;
    int   nbActifs = 0;

    printf("\n--- Catalogue de %s ---\n", b->nom);
    afficherEnteteProduits();
    for (int i = 0; i < b->nbProduits; i++)
    {
        const Produit *p = &b->produits[i];
        if (!p->actif) continue;
        afficherLigneProduit(p);
        valorisation += p->prixUnitaireHT * (float)p->quantiteStock;
        nbActifs++;
    }
    afficherSeparateur();
    printf("  %d produit(s) actif(s) - Valorisation totale du stock : %.2f EUR HT\n",
           nbActifs, valorisation);
}

void rechercherProduit(const Boutique *b)
{
    char texte[TAILLE_DESIGNATION];
    int  mode, trouve = 0;

    printf("\n--- Recherche d'un produit ---\n");
    printf("  1. Par reference exacte\n");
    printf("  2. Par mot-cle dans la designation\n");
    mode = lireEntier("  Votre choix : ", 1, 2);
    if (finDeSaisie()) return;

    if (mode == 1)
    {
        int idx;
        lireChaineNonVide("  Reference : ", texte, TAILLE_REF);
        enMajuscules(texte);
        idx = trouverProduit(b, texte);
        if (idx != -1 && b->produits[idx].actif)
        {
            afficherEnteteProduits();
            afficherLigneProduit(&b->produits[idx]);
            trouve = 1;
        }
    }
    else
    {
        lireChaineNonVide("  Mot-cle : ", texte, (int)sizeof texte);
        for (int i = 0; i < b->nbProduits; i++)
        {
            if (b->produits[i].actif && contientMotCle(b->produits[i].designation, texte))
            {
                if (!trouve) afficherEnteteProduits();
                afficherLigneProduit(&b->produits[i]);
                trouve++;
            }
        }
    }
    if (!trouve)
        printf("  Aucun produit trouve.\n");
}

void afficherAlertesStock(const Boutique *b)
{
    int nb = 0;

    printf("\n--- Alertes de stock (stock <= seuil) ---\n");
    for (int i = 0; i < b->nbProduits; i++)
    {
        const Produit *p = &b->produits[i];
        if (p->actif && p->quantiteStock <= p->seuilAlerte)
        {
            if (nb == 0) afficherEnteteProduits();
            afficherLigneProduit(p);
            nb++;
        }
    }
    if (nb == 0)
        printf("  Aucun produit en alerte.\n");
    else
        printf("  %d produit(s) a reapprovisionner.\n", nb);
}

/* Bonus #1 : chaque critere laisse vide est ignore */
void rechercheMulticritere(const Boutique *b)
{
    char  motCle[TAILLE_DESIGNATION];
    char  categorie[TAILLE_CATEGORIE];
    float prixMin, prixMax;
    int   nb = 0;

    printf("\n--- Recherche multicritere ---\n");
    lireChaine("  Mot-cle dans la designation (vide = tous) : ", motCle, (int)sizeof motCle);
    lireChaine("  Categorie (vide = toutes)                  : ", categorie, (int)sizeof categorie);
    prixMin = lireReel("  Prix HT minimum : ", 0.0f, 1000000.0f);
    prixMax = lireReel("  Prix HT maximum : ", 0.0f, 1000000.0f);
    if (finDeSaisie()) return;
    if (prixMax < prixMin) /* l'utilisateur a inverse les bornes */
    {
        float t = prixMin;
        prixMin = prixMax;
        prixMax = t;
    }

    for (int i = 0; i < b->nbProduits; i++)
    {
        const Produit *p = &b->produits[i];
        if (!p->actif) continue;
        if (motCle[0] != '\0' && !contientMotCle(p->designation, motCle)) continue;
        if (categorie[0] != '\0' && !egalSansCasse(p->categorie, categorie)) continue;
        if (p->prixUnitaireHT < prixMin || p->prixUnitaireHT > prixMax) continue;

        if (nb == 0) afficherEnteteProduits();
        afficherLigneProduit(p);
        nb++;
    }
    if (nb == 0)
        printf("  Aucun produit ne correspond a ces criteres.\n");
    else
        printf("  %d produit(s) trouve(s).\n", nb);
}
