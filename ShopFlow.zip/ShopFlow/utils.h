/* ==========================================================================
 * utils.h - Saisie securisee, validation des donnees, affichage formate
 * ========================================================================== */
#ifndef UTILS_H
#define UTILS_H

#include "types.h"

/* --- Saisie securisee (fgets : aucun debordement de buffer) -------------- */
void  lireChaine(const char *message, char *dest, int taille);
void  lireChaineNonVide(const char *message, char *dest, int taille);
int   lireEntier(const char *message, int min, int max);
float lireReel(const char *message, float min, float max);
int   finDeSaisie(void);      /* 1 si l'entree standard est fermee */

/* --- Dates --------------------------------------------------------------- */
int  estBissextile(int annee);
int  dateValide(Date d);
void saisirDate(const char *message, Date *d);
void afficherDate(Date d);

/* --- Validations --------------------------------------------------------- */
int emailValide(const char *email);
int telephoneValide(const char *tel);
int codePostalValide(const char *cp);

/* --- Outils sur les chaines ---------------------------------------------- */
void enMajuscules(char *s);
int  contientMotCle(const char *texte, const char *motCle);
int  egalSansCasse(const char *a, const char *b);

/* --- Divers -------------------------------------------------------------- */
float arrondi2(float x);      /* arrondi au centime */
void  afficherSeparateur(void);

#endif /* UTILS_H */
