/* ==========================================================================
 * main.c - Point d'entree de ShopFlow (XTI101)
 * --------------------------------------------------------------------------
 * Role : initialiser la Boutique, faire tourner les menus, puis liberer
 * toute la memoire avant de quitter (aucune fuite sous valgrind).
 *
 * Compilation : make        (ou : gcc -Wall -Wextra -std=c99 -g *.c -o shopflow)
 * Execution   : ./shopflow
 * ========================================================================== */
#include <stdio.h>
#include <stdlib.h>

#include "types.h"
#include "utils.h"
#include "produit.h"
#include "client.h"
#include "commande.h"
#include "statistique.h"
#include "initialisation.h"

/* --------------------------------------------------------------------------
 * Lecture d'un choix de menu : saisie securisee du module utils.c
 * -------------------------------------------------------------------------- */
static int lireChoix(int max)
{
    return lireEntier("  Votre choix : ", 0, max);
}

/* ==========================================================================
 * SOUS-MENUS : un seul motif, applique 4 fois.
 * Chaque sous-menu recoit la Boutique (possedee par main).
 * ========================================================================== */

static void menuProduits(Boutique *b)
{
    int choix;
    do
    {
        printf("\n===== GESTION DES PRODUITS =====\n");
        printf("  1. Ajouter un produit\n");
        printf("  2. Modifier un produit (prix, stock, seuil)\n");
        printf("  3. Supprimer un produit\n");
        printf("  4. Afficher le catalogue\n");
        printf("  5. Rechercher un produit\n");
        printf("  6. Recherche multicritere (bonus)\n");
        printf("  0. Retour au menu principal\n");
        choix = lireChoix(6);

        switch (choix)
        {
            case 1: ajouterProduit(b);        break;
            case 2: modifierProduit(b);       break;
            case 3: supprimerProduit(b);      break;
            case 4: afficherCatalogue(b);     break;
            case 5: rechercherProduit(b);     break;
            case 6: rechercheMulticritere(b); break;
            case 0:                           break; /* retour automatique */
            default: printf("  [!] Choix invalide.\n"); break;
        }
    } while (choix != 0);
}

static void menuClients(Boutique *b)
{
    int choix;
    do
    {
        printf("\n===== GESTION DES CLIENTS =====\n");
        printf("  1. Ajouter un client\n");
        printf("  2. Modifier un client\n");
        printf("  3. Supprimer un client\n");
        printf("  4. Afficher la liste des clients\n");
        printf("  5. Afficher la fiche d'un client\n");
        printf("  0. Retour au menu principal\n");
        choix = lireChoix(5);

        switch (choix)
        {
            case 1: ajouterClient(b);        break;
            case 2: modifierClient(b);       break;
            case 3: supprimerClient(b);      break;
            case 4: afficherListeClients(b); break;
            case 5: afficherClient(b);       break;
            case 0:                          break;
            default: printf("  [!] Choix invalide.\n"); break;
        }
    } while (choix != 0);
}

static void menuCommandes(Boutique *b)
{
    int choix;
    do
    {
        printf("\n===== GESTION DES COMMANDES =====\n");
        printf("  1. Creer une commande\n");
        printf("  2. Afficher une commande\n");
        printf("  3. Ajouter une ligne (EN_COURS)\n");
        printf("  4. Supprimer une ligne (EN_COURS)\n");
        printf("  5. Faire avancer le statut\n");
        printf("  6. Annuler une commande (EN_COURS)\n");
        printf("  7. Appliquer un code promo (bonus)\n");
        printf("  0. Retour au menu principal\n");
        choix = lireChoix(7);

        switch (choix)
        {
            case 1: creerCommande(b);          break;
            case 2: afficherUneCommande(b);    break;
            case 3: ajouterLigneCommande(b);   break;
            case 4: supprimerLigneCommande(b); break;
            case 5: changerStatutCommande(b);  break;
            case 6: annulerCommande(b);        break;
            case 7: appliquerCodePromo(b);     break;
            case 0:                            break;
            default: printf("  [!] Choix invalide.\n"); break;
        }
    } while (choix != 0);
}

static void menuStatistiques(Boutique *b)
{
    int choix;
    do
    {
        printf("\n===== STATISTIQUES =====\n");
        printf("  1. Chiffre d'affaires global\n");
        printf("  2. Chiffre d'affaires par periode\n");
        printf("  3. Palmares produits (top 5)\n");
        printf("  4. Palmares clients\n");
        printf("  5. Alertes de stock\n");
        printf("  0. Retour au menu principal\n");
        choix = lireChoix(5);

        switch (choix)
        {
            case 1: afficherChiffreAffaires(b);  break;
            case 2: afficherCAParPeriode(b);     break;
            case 3: afficherPalmaresProduits(b); break;
            case 4: afficherPalmaresClients(b);  break;
            case 5: afficherAlertesStock(b);     break;
            case 0:                              break;
            default: printf("  [!] Choix invalide.\n"); break;
        }
    } while (choix != 0);
}

/* ==========================================================================
 * PROGRAMME PRINCIPAL
 * ========================================================================== */
int main(void)
{
    Boutique boutique;
    int      choix;

    /* Initialisation : boutique vide puis jeu de donnees de demonstration */
    initialiserBoutique(&boutique);
    if (!initialiserDonneesTest(&boutique))
    {
        printf("  [!] Echec du chargement des donnees de test.\n");
        detruireBoutique(&boutique);
        return EXIT_FAILURE;
    }

    printf("==============================================\n");
    printf("  SHOPFLOW - Boutique en ligne\n");
    printf("  %d produits, %d clients charges\n", boutique.nbProduits, boutique.nbClients);
    printf("==============================================\n");

    do
    {
        printf("\n===== MENU PRINCIPAL =====\n");
        printf("  1. Gestion des produits\n");
        printf("  2. Gestion des clients\n");
        printf("  3. Gestion des commandes\n");
        printf("  4. Statistiques\n");
        printf("  0. Quitter\n");
        choix = lireChoix(4);

        switch (choix)
        {
            case 1: menuProduits(&boutique);     break;
            case 2: menuClients(&boutique);      break;
            case 3: menuCommandes(&boutique);    break;
            case 4: menuStatistiques(&boutique); break;
            case 0: printf("\n  Au revoir !\n"); break;
            default: printf("  [!] Choix invalide.\n"); break;
        }
    } while (choix != 0);

    /* Liberation complete de la memoire avant de quitter */
    detruireBoutique(&boutique);
    return EXIT_SUCCESS;
}
