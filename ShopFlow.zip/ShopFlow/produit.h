/* ==========================================================================
 * produit.h - Module Catalogue produits
 * CRUD des produits, gestion du stock et des alertes de reapprovisionnement
 * ========================================================================== */
#ifndef PRODUIT_H
#define PRODUIT_H

#include "types.h"

/* Recherche par reference exacte (produits actifs ET supprimes).
 * Retourne l'indice dans b->produits, ou -1. */
int  trouverProduit(const Boutique *b, const char *reference);

/* Vrai si la reference apparait dans une commande non annulee */
int  produitUtiliseDansCommande(const Boutique *b, const char *reference);

void ajouterProduit(Boutique *b);
void modifierProduit(Boutique *b);
void supprimerProduit(Boutique *b);
void afficherCatalogue(const Boutique *b);
void rechercherProduit(const Boutique *b);
void afficherAlertesStock(const Boutique *b);

/* Bonus creativite #1 : mot-cle + categorie + fourchette de prix */
void rechercheMulticritere(const Boutique *b);

#endif /* PRODUIT_H */
