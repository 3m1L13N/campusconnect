/* ==========================================================================
 * commande.h - Module Commandes
 * Creation des commandes, gestion des lignes, calcul des montants
 * ========================================================================== */
#ifndef COMMANDE_H
#define COMMANDE_H

#include "types.h"

/* Calcul en cascade : lignes -> brut -> remise -> promo -> HT -> TVA -> port -> TTC */
void calculerCommande(Commande *c);

/* Points de fidelite rapportes par une commande (0 si ANNULEE) */
int  pointsCommande(const Commande *c);

/* Remplit une ligne a partir d'un produit du catalogue (prix et libelle figes) */
void remplirLigne(LigneCommande *l, const Produit *p, int quantite);

/* Ajoute une copie de la commande dans l'historique du client (realloc si besoin).
 * Le tableau de lignes appartient ensuite au client. Retourne 1 si OK. */
int  ajouterCommandeAuClient(Client *cl, const Commande *c);

/* Recherche une commande par numero ; *proprietaire recoit son client */
Commande *trouverCommande(Boutique *b, int numero, Client **proprietaire);

void afficherDetailCommande(const Commande *c);

void creerCommande(Boutique *b);
void afficherUneCommande(Boutique *b);
void ajouterLigneCommande(Boutique *b);
void supprimerLigneCommande(Boutique *b);
void changerStatutCommande(Boutique *b);
void annulerCommande(Boutique *b);

/* Bonus creativite #2 : code promotionnel sur une commande EN_COURS */
void appliquerCodePromo(Boutique *b);

#endif /* COMMANDE_H */
