/* ==========================================================================
 * client.c - Module Clients
 * ========================================================================== */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "client.h"
#include "utils.h"

/* ------------------------------------------------------------------------ */
/* Fonctions internes                                                       */
/* ------------------------------------------------------------------------ */

static int agrandirRepertoire(Boutique *b)
{
    int nouvelleCapacite = (b->capaciteClients == 0) ? CAPACITE_INIT_CLIENTS
                                                     : b->capaciteClients * 2;
    Client *tmp = (Client *)realloc(b->clients, (size_t)nouvelleCapacite * sizeof(Client));

    if (tmp == NULL)
    {
        printf("  [!] Erreur : memoire insuffisante, client non ajoute.\n");
        return 0;
    }
    b->clients = tmp;
    b->capaciteClients = nouvelleCapacite;
    return 1;
}

/* Unicite de l'email sur TOUS les clients (y compris supprimes),
 * sauf le client idIgnore (utile lors d'une modification). */
static int emailDejaUtilise(const Boutique *b, const char *email, int idIgnore)
{
    for (int i = 0; i < b->nbClients; i++)
        if (b->clients[i].idClient != idIgnore && egalSansCasse(b->clients[i].email, email))
            return 1;
    return 0;
}

/* Saisie d'un email valide et unique. vide autorise -> on garde l'ancien.
 * Retourne 1 si dest a ete rempli. */
static int saisirEmail(const Boutique *b, char *dest, int idIgnore, int videAutorise)
{
    char email[TAILLE_EMAIL];

    while (!finDeSaisie())
    {
        if (videAutorise)
            lireChaine("  Email (vide = inchange) : ", email, (int)sizeof email);
        else
            lireChaineNonVide("  Email : ", email, (int)sizeof email);

        if (email[0] == '\0')
            return 0;
        if (!emailValide(email))
            printf("  [!] Email invalide (format attendu : nom@domaine.fr).\n");
        else if (emailDejaUtilise(b, email, idIgnore))
            printf("  [!] Cet email est deja utilise par un autre client.\n");
        else
        {
            strcpy(dest, email);
            return 1;
        }
    }
    return 0;
}

static int saisirTelephone(char *dest, int videAutorise)
{
    char tel[TAILLE_TEL];

    while (!finDeSaisie())
    {
        if (videAutorise)
            lireChaine("  Telephone (vide = inchange) : ", tel, (int)sizeof tel);
        else
            lireChaineNonVide("  Telephone (10 chiffres) : ", tel, (int)sizeof tel);

        if (tel[0] == '\0')
            return 0;
        if (telephoneValide(tel))
        {
            strcpy(dest, tel);
            return 1;
        }
        printf("  [!] Le telephone doit contenir exactement 10 chiffres.\n");
    }
    return 0;
}

/* Modifie un champ texte : une saisie vide conserve la valeur actuelle */
static void modifierChamp(const char *libelle, char *champ, int taille)
{
    char message[120];
    char saisie[TAILLE_RUE];

    snprintf(message, sizeof message, "  %s [%s] : ", libelle, champ);
    lireChaine(message, saisie, taille);
    if (saisie[0] != '\0')
        strcpy(champ, saisie);
}

/* Demande un identifiant et retourne l'indice d'un client ACTIF, ou -1 */
static int saisirClientActif(const Boutique *b)
{
    int id  = lireEntier("  Identifiant du client : ", 1, INT_MAX);
    int idx = trouverClient(b, id);

    if (finDeSaisie()) return -1;
    if (idx == -1 || !b->clients[idx].actif)
    {
        printf("  [!] Aucun client actif avec l'identifiant %d.\n", id);
        return -1;
    }
    return idx;
}

static int aCommandeNonAnnulee(const Client *c)
{
    for (int j = 0; j < c->nbCommandes; j++)
        if (strcmp(c->commandes[j].statut, STATUT_ANNULEE) != 0)
            return 1;
    return 0;
}

/* ------------------------------------------------------------------------ */
/* Fonctions publiques                                                      */
/* ------------------------------------------------------------------------ */

int trouverClient(const Boutique *b, int idClient)
{
    for (int i = 0; i < b->nbClients; i++)
        if (b->clients[i].idClient == idClient)
            return i;
    return -1;
}

float chiffreAffairesClient(const Client *c, int enTTC)
{
    float total = 0.0f;

    for (int j = 0; j < c->nbCommandes; j++)
    {
        const Commande *cmd = &c->commandes[j];
        if (strcmp(cmd->statut, STATUT_ANNULEE) == 0)
            continue;
        total += enTTC ? cmd->montantTTC : cmd->montantHT;
    }
    return total;
}

int nbCommandesValides(const Client *c)
{
    int nb = 0;
    for (int j = 0; j < c->nbCommandes; j++)
        if (strcmp(c->commandes[j].statut, STATUT_ANNULEE) != 0)
            nb++;
    return nb;
}

void saisirAdresse(Adresse *a)
{
    lireChaineNonVide("  Rue (numero et voie) : ", a->rue, (int)sizeof a->rue);
    lireChaineNonVide("  Ville                : ", a->ville, (int)sizeof a->ville);
    do
    {
        lireChaineNonVide("  Code postal (5 chiffres) : ", a->codePostal, (int)sizeof a->codePostal);
        if (!codePostalValide(a->codePostal) && !finDeSaisie())
            printf("  [!] Code postal invalide.\n");
    } while (!codePostalValide(a->codePostal) && !finDeSaisie());
    lireChaineNonVide("  Pays                 : ", a->pays, (int)sizeof a->pays);
}

void ajouterClient(Boutique *b)
{
    Client c;

    printf("\n--- Ajout d'un client ---\n");
    memset(&c, 0, sizeof c);
    lireChaineNonVide("  Nom    : ", c.nom, (int)sizeof c.nom);
    lireChaineNonVide("  Prenom : ", c.prenom, (int)sizeof c.prenom);
    saisirEmail(b, c.email, -1, 0);
    saisirTelephone(c.telephone, 0);
    printf("  Adresse de livraison :\n");
    saisirAdresse(&c.adresse);
    if (finDeSaisie()) return;

    c.pointsFidelite    = 0;
    c.nbCommandes       = 0;
    c.capaciteCommandes = 0;
    c.commandes         = NULL; /* alloue a la premiere commande */
    c.actif             = 1;

    if (b->nbClients == b->capaciteClients && !agrandirRepertoire(b))
        return;

    c.idClient = b->idClientSuivant++; /* attribue par la boutique, jamais saisi */
    b->clients[b->nbClients++] = c;
    printf("  [OK] Client %s %s ajoute avec l'identifiant %d.\n", c.prenom, c.nom, c.idClient);
}

void modifierClient(Boutique *b)
{
    int     idx;
    Client *c;

    printf("\n--- Modification d'un client ---\n");
    idx = saisirClientActif(b);
    if (idx == -1) return;
    c = &b->clients[idx];

    printf("  (Laisser vide pour conserver la valeur entre crochets)\n");
    modifierChamp("Nom", c->nom, (int)sizeof c->nom);
    modifierChamp("Prenom", c->prenom, (int)sizeof c->prenom);
    printf("  Email actuel : %s\n", c->email);
    saisirEmail(b, c->email, c->idClient, 1);
    printf("  Telephone actuel : %s\n", c->telephone);
    saisirTelephone(c->telephone, 1);

    printf("  Adresse actuelle : %s, %s %s, %s\n",
           c->adresse.rue, c->adresse.codePostal, c->adresse.ville, c->adresse.pays);
    if (lireEntier("  Modifier l'adresse de livraison ? (1 = oui, 0 = non) : ", 0, 1) == 1)
    {
        Adresse nouvelle;
        saisirAdresse(&nouvelle);
        if (!finDeSaisie())
            c->adresse = nouvelle;
    }
    printf("  [OK] Client %d mis a jour.\n", c->idClient);
}

void supprimerClient(Boutique *b)
{
    int idx;

    printf("\n--- Suppression d'un client ---\n");
    idx = saisirClientActif(b);
    if (idx == -1) return;

    if (aCommandeNonAnnulee(&b->clients[idx]))
    {
        printf("  [!] Suppression refusee : ce client a des commandes non annulees.\n");
        return;
    }
    b->clients[idx].actif = 0; /* suppression logique */
    printf("  [OK] Client %d supprime (desactive).\n", b->clients[idx].idClient);
}

void afficherListeClients(const Boutique *b)
{
    int nb = 0;

    printf("\n--- Liste des clients ---\n");
    afficherSeparateur();
    printf("  %-4s %-14s %-12s %-22s %5s %11s %11s %6s\n",
           "Id", "Nom", "Prenom", "Email", "Cmd", "CA HT", "CA TTC", "Points");
    afficherSeparateur();
    for (int i = 0; i < b->nbClients; i++)
    {
        const Client *c = &b->clients[i];
        if (!c->actif) continue;
        printf("  %-4d %-14.14s %-12.12s %-22.22s %5d %11.2f %11.2f %6d\n",
               c->idClient, c->nom, c->prenom, c->email, c->nbCommandes,
               chiffreAffairesClient(c, 0), chiffreAffairesClient(c, 1), c->pointsFidelite);
        nb++;
    }
    afficherSeparateur();
    printf("  %d client(s) actif(s).\n", nb);
}

void afficherClient(const Boutique *b)
{
    int           idx;
    const Client *c;

    printf("\n--- Fiche client ---\n");
    idx = saisirClientActif(b);
    if (idx == -1) return;
    c = &b->clients[idx];

    afficherSeparateur();
    printf("  Client n.%d : %s %s\n", c->idClient, c->prenom, c->nom);
    printf("  Email     : %s\n", c->email);
    printf("  Telephone : %s\n", c->telephone);
    printf("  Adresse   : %s, %s %s, %s\n",
           c->adresse.rue, c->adresse.codePostal, c->adresse.ville, c->adresse.pays);
    printf("  Points de fidelite : %d\n", c->pointsFidelite);
    printf("  Chiffre d'affaires : %.2f EUR HT / %.2f EUR TTC\n",
           chiffreAffairesClient(c, 0), chiffreAffairesClient(c, 1));
    afficherSeparateur();

    printf("  Historique des commandes (%d) :\n", c->nbCommandes);
    if (c->nbCommandes == 0)
    {
        printf("  Aucune commande.\n");
        return;
    }
    printf("  %-8s %-12s %-10s %7s %11s %11s\n", "Numero", "Date", "Statut", "Lignes", "HT", "TTC");
    for (int j = 0; j < c->nbCommandes; j++)
    {
        const Commande *cmd = &c->commandes[j];
        printf("  %-8d ", cmd->numero);
        afficherDate(cmd->dateCommande);
        printf("   %-10s %7d %11.2f %11.2f\n",
               cmd->statut, cmd->nbLignes, cmd->montantHT, cmd->montantTTC);
        for (int k = 0; k < cmd->nbLignes; k++)
            printf("           - %-10s %-24.24s x%d\n", cmd->lignes[k].refProduit,
                   cmd->lignes[k].designation, cmd->lignes[k].quantite);
    }
}
