/* ==========================================================================
 * statistique.h - Module Statistiques
 * Chiffre d'affaires, palmares produits et clients (tri par selection)
 * Toutes les statistiques excluent les commandes ANNULEE.
 * ========================================================================== */
#ifndef STATISTIQUE_H
#define STATISTIQUE_H

#include "types.h"

void afficherChiffreAffaires(const Boutique *b);    /* global HT et TTC     */
void afficherCAParPeriode(const Boutique *b);       /* par mois ou par annee */
void afficherPalmaresProduits(const Boutique *b);   /* top 5 quantites       */
void afficherPalmaresClients(const Boutique *b);    /* classement par CA HT  */

#endif /* STATISTIQUE_H */
